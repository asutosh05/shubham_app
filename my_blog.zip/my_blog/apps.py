from django.apps import AppConfig


class MyBlogConfig(AppConfig):
    name = 'my_blog'
